class Entry:
    def __init__(self, key, value, ts):
        self.key = key
        self.value = value
        self.ts = ts


